function M = EuclideanDistance(X, C);
M = eye(size(X,2));